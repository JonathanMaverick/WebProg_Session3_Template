<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Session3</title>
    <link rel="stylesheet" href="<?php echo e(asset('css/styles.css')); ?>">
</head>
<body>
    <div class="container">
        <table class="table">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Photo</th>
                    <th>Title</th>
                    <th>Description</th>
                    <th>Episodes</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
            </tbody>
        </table>
    </div>

    <div class="container">
        <h3>Insert Movie</h3>
        <form action="">
            <label for="imageInsert">Image</label>
            <input type="file" id="imageInsert" name="image">
            <label for="titleInsert">Title</label>
            <input id="titleInsert" type="text" name="title" placeholder="Title">
            <label for="descInsert">Description</label>
            <input id="descInsert" type="text" name="desc" placeholder="Description">
            <button type="submit" value="Insert">Insert</button>
        </form>
    </div>
    <div class="container">
        <h3>Insert Episode</h3>
        <form action="">
            <label for="movieIDInsert">MovieID</label>
            <input id="movieIDInsert" type="text" name="movieID" placeholder="MovieID">
            <label for="episodeInsert">Episode</label>
            <input id="episodeInsert" type="text" name="episode" placeholder="Episode">
            <label for="titleInsert">Title</label>
            <input id="titleInsert" type="text" name="title" placeholder="Title">
            <button type="submit" value="Insert">Insert</button>
        </form>
    </div>
    <div class="container">
        <h3>Update Movies</h3>
        <form action="">
            <label for="idUpdate">ID</label>
            <input id="idUpdate" type="text" name="id" placeholder="ID">
            <label for="imageUpdate">Image</label>
            <input type="file" id="imageUpdate" name="image">
            <label for="titleUpdate">Title</label>
            <input id="titleUpdate" type="text" name="title" placeholder="Title">
            <label for="descUpdate">Description</label>
            <input id="descUpdate" type="text" name="desc" placeholder="Description">
            <button type="submit" value="Update">Update</button>
        </form>
    </div>
</body>
</html>
<?php /**PATH C:\Sekolah\Kuliah\Aslab\Teaching\Even2324\WebProg\Session3\Session3\resources\views/index.blade.php ENDPATH**/ ?>